# backend/app.py
from fastapi import FastAPI
from pydantic import BaseModel
import pickle

# Load model + vectorizer
with open("toxic_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

app = FastAPI()

class CommentInput(BaseModel):
    text: str

@app.post("/predict")
def predict(input: CommentInput):
    X = vectorizer.transform([input.text])
    prediction = model.predict(X)[0]
    return {"prediction": int(prediction)}
